export class FlattenJsonDto {
  data: any;
}

