export class UpdateUserDto {
  name?: string;
  email?: string;
  isActive?: boolean;
}

